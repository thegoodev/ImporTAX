import 'dart:async' show Future;
import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';

void main(){
    print("stuff");
}

Future<String> _loadArancelAsset() async{
  return await rootBundle.loadString('arancel.json');
}

Future loadData() async {
  String jsonArancel = await _loadArancelAsset();
  _parseJson(jsonArancel);
}

void _parseJson( String jsonString){
  Map decoded = jsonDecode(jsonString);

  print(decoded);
}