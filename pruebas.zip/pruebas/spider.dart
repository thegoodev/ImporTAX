import 'package:http/http.dart' as http;
import 'package:html/parser.dart' show parse;

RegExp rxPartida = new RegExp(r"\d{4}\.\d{2}\.\d{2}\.\d{2}");
RegExp rx = new RegExp(r"\d{2}\.\d{2}");

var allPartidas = [];

var everything = [];

void main(){
    ask();
}

void count() async {

  var url = "http://www.aduanet.gob.pe/itarancel/arancelS01Alias?accion=buscarPartida&esframe=1";

  final response = await http.get(url);

  if(response.statusCode == 200){

    var counter = 0;

    var document = parse(response.body);

    var tables = document.getElementsByTagName("td");

    for(var i=0; i<tables.length;i++){

      var curr = tables[i].text.trim();

      //print(curr);
      //counter ++;

      if(rxPartida.hasMatch(curr) && curr.length==13){

        curr = curr.replaceAll(".", "");

        counter ++;

      }

    }

    print(counter);

  }

}

void ask() async {

  var url = "http://www.aduanet.gob.pe/itarancel/arancelS01Alias?accion=buscarPartida&esframe=1";

  final response = await http.get(url);

  if(response.statusCode == 200){

        var document = parse(response.body);

        var tables = document.getElementsByTagName("td");

        for(var i=0; i<tables.length;i++){

          var curr = tables[i].text.trim();

          if(rxPartida.hasMatch(curr) && curr.length==13){

            curr = curr.replaceAll(".", "");

            print(curr);

          if(!(allPartidas.contains(curr))){

              var parent = "http://www.aduanet.gob.pe/servlet/XAIScroll?Partida=$curr";

              final rParent = await http.get(parent);

              if(rParent.statusCode == 200){
                var _documento = parse(rParent.body);

                var _otros = _documento.getElementsByTagName("td");

                var childs = [];

                var seccion = (_otros[0].text.trim().contains("SECCIÓN:"))?_otros[1].text.trim(): "Sin Sección";
                var name = (_otros[2].text.trim().contains("CAPITULO:"))?_otros[3].text.trim():"Sin Capitulo";

                for(var i=0; i<_otros.length; i++){

                  var t = _otros[i].text.trim();

                  if(rxPartida.hasMatch(t) && (t.length==13)){

                    var _partida = t.replaceAll(".", "");

                    var u = "http://www.aduanet.gob.pe/servlet/YAIScroll?Partida=$_partida";

                    final response = await http.get(u);

                    var productos = [];

                    if(response.statusCode == 200){

                      var documento = parse(response.body);

                      var tables = documento.getElementsByTagName("td");

                      for (var i = 0; i < tables.length; i++) {

                          var tmp = tables[i].text;
                          var isProductType = (tmp =="TIPO DE PRODUCTO: ");

                          if(isProductType){
                            var descripcion = tables[i+1].text;
                            descripcion = descripcion.contains(";")?descripcion.substring(descripcion.indexOf(";")+1):descripcion;
                    
                            var av = getPct(tables[1+4].text);
                            var fixed = false;

                            var isc;

                            if(tables[i+7].text.trim() == "Detalle"){

                              final info = await http.get("http://www.aduanet.gob.pe/servlet/AIisc?Partida=$_partida");
                              if(info.statusCode == 200){

                                fixed = true;

                                var este = parse(info.body);

                                var tablas = este.getElementsByTagName("td");

                                isc = tablas[5].text;
                                var init = tablas[6].text;
                                var fin = tablas[7].text;

                                if(num.parse(fin.substring(6)) < 2019){
                                  print("fuck off");
                                  print("valor: $isc \ninit: $init \nfin: $fin");
                                }

                              }
                            }else{
                              isc = getPct(tables[i+7].text);
                            }

                            var seguro = getPct(tables[i+17].text);
                            var tasa = getPct(tables[i+19].text);
                    
                            var unidad = tables[i+21].text;

                          productos.add({"\"tipo\"": "\"$descripcion\"","\"fixed\"":fixed, "\"av\"": av, "\"isc\"": isc, "\"seguro\"": seguro, "\"tasa\"": tasa, "\"unidad\"": "\"$unidad\""});
                        }
                      }
                    }

                      var r = _otros[i+1].text.trim();

                      r = r.replaceAll("\'", "");
                      r = r.replaceAll("\"", "");

                      childs.add({"\"nombre\"": "\"$r\"", "\"partida\"": "\"$t\"", "\"productos\"":productos});

                      print(productos);
                      
                      allPartidas.add(_partida);

                  }
                      
                }

                var secc = everything.firstWhere((var thing)=>(thing["\"seccion\""]=="\"$seccion\""), orElse: ()=> null);
                
                if(secc != null){
                  var cap = secc["\"capitulos\""].firstWhere((var thing)=>(thing["\"name\""]=="\"$name\""), orElse: ()=> null);
                  if(cap != null){
                    cap["\"children\""].addAll(childs);
                  }else{
                    secc["\"capitulos\""].add({"\"name\"":"\"$name\"","\"children\"":childs});
                  }
                }else{
                  everything.add({"\"seccion\"": "\"$seccion\"", "\"capitulos\"":[{"\"name\"":"\"$name\"","\"children\"": childs}]});
                }
            }
  }

        }
      }

      print(everything);
      print(allPartidas);
      print(allPartidas.length);

  }else{
    throw Exception('failed to load post');
  }
}

num getPct(String str){
  str = str.trim();
  if(str.contains("%")){
    str = str.replaceAll("%", "");
  }
  return num.tryParse(str)*0.01;
}

void clasify(String curr) async{

  curr = curr.replaceAll(".", "");
  var parent = "http://www.aduanet.gob.pe/servlet/XAIScroll?Partida=$curr";

  final rParent = await http.get(parent);

  if(rParent.statusCode == 200){
    var _documento = parse(rParent.body);

    var _otros = _documento.getElementsByTagName("td");

    var _childs = [];

    for(var i=0; i<(_otros.length-1); i++){

      var t = _otros[i].text.trim();

      if(rx.hasMatch(t)){
      
        var s = t.length;
        var par = t.replaceAll(".", "");

        var r = _otros[i+1].text.trim();

        t = t.replaceAll("\'", "");
        t = t.replaceAll("\'", "");

        r = r.replaceAll("\'", "");
        r = r.replaceAll("\"", "");
        
        if(rxPartida.hasMatch(t) && s==13){

          var sub = par.substring(0,4);
          
          _childs.firstWhere((var o)=> o["\"sub\""]=="\"$sub\"", orElse: ()=>null)["\"children\""].add({"\"nombre\"": "\"$r\"", "\"partida\"": "\"$t\""});
          
          //t = t.replaceAll(".", "");
          //allPartidas.add(t);
        }else if(s == 5){

          var n = _childs.firstWhere((var o)=> o["\"sub\""]=="\"$par\"", orElse: ()=>null);

          if(n == null){
            _childs.add({"\"nombre\"":"\"$r\"" ,"\"sub\"": "\"$par\"", "\"children\"":[]});
          }

        }
      }
                      
    }

    print(_childs);
  
  }
}